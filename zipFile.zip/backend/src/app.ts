// backend/src/app.ts
// This file will set up your Express application
console.log('Backend app.ts file created.');
