// backend/src/utils/jwt.ts
// JWT token utilities
console.log('Backend jwt.ts file created.');
