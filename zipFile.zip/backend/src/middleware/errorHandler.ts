// backend/src/middleware/errorHandler.ts
// Handles error catching and response formatting
console.log('Backend errorHandler.ts file created.');
