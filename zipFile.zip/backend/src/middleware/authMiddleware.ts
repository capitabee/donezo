// backend/src/middleware/authMiddleware.ts
// Handles authentication middleware
console.log('Backend authMiddleware.ts file created.');
