// backend/src/controllers/adminController.ts
// Handles admin-specific logic
console.log('Backend adminController.ts file created.');
