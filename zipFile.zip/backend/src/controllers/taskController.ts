// backend/src/controllers/taskController.ts
// Handles task-related logic
console.log('Backend taskController.ts file created.');
