// backend/src/controllers/userController.ts
// Handles user-related logic
console.log('Backend userController.ts file created.');
