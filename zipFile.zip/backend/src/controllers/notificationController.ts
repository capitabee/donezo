// backend/src/controllers/notificationController.ts
// Handles notification logic
console.log('Backend notificationController.ts file created.');
