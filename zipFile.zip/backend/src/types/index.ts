// backend/src/types/index.ts
// Centralized TypeScript types for the backend
console.log('Backend types/index.ts file created.');
