// backend/src/server.ts
// This file will start your Express server
console.log('Backend server.ts file created.');
