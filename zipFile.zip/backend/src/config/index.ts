// backend/src/config/index.ts
// This file will handle environment variables and configuration
console.log('Backend config/index.ts file created.');
