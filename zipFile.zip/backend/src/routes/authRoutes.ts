// backend/src/routes/authRoutes.ts
// Defines authentication routes
console.log('Backend authRoutes.ts file created.');
