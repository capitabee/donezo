// backend/src/routes/adminRoutes.ts
// Defines admin-specific routes
console.log('Backend adminRoutes.ts file created.');
