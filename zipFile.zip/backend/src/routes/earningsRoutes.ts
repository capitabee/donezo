// backend/src/routes/earningsRoutes.ts
// Defines earnings-related routes
console.log('Backend earningsRoutes.ts file created.');
