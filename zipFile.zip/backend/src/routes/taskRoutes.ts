// backend/src/routes/taskRoutes.ts
// Defines task-related routes
console.log('Backend taskRoutes.ts file created.');
