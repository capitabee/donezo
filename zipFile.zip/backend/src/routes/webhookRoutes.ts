// backend/src/routes/webhookRoutes.ts
// Defines webhook routes (e.g., for Stripe)
console.log('Backend webhookRoutes.ts file created.');
