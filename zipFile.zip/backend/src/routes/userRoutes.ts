// backend/src/routes/userRoutes.ts
// Defines user-related routes
console.log('Backend userRoutes.ts file created.');
